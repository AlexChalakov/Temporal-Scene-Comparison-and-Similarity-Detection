# ReadMe File Highlight usage

# Libraries
1. requirements.txt - a text file with a list of all the libraries used in the project

# Data Preparation
2. data_processing.m - Matlab File - that is used for the initial data processing step, splitting the data into tables
3. data_processing_b.m - Matlab File - secondary data processing step - structuring data into families of testing, training and validation and putting it into the designated folder
4. KFoldCrossValidation.m - Matlab File - it is performing the k-fold cross validation method and its called in data_processing.m
5. check.m - Matlab File - it was used as a check function to account for the overlapping images between the training and testing
6. mkttv.m - Matlab File - used to build the table for all of the relationships between the pairs of images, where we get their ground truth if they are a match or not
# Siamese Networks
7. testSiameseAC.py - Python File - all of the code for the Siamese Networks, it is referenced in the report

# SIFT
8. TestSIFT.m - Matlab File - code for the SIFT approach
9. sift_mosaic.m - Matlab File - the actual mosaic that is called in TestSIFT.m and demonstrates matching two images using SIFT and RANSAC
